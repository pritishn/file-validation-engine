import React, { Component } from 'react';
import { BrowserRouter, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';

class MakeNewTemplates extends Component {
    state = {
        name: '',
        creator: '',
        description: '',
        params: [],
        field: {
            fieldName: '',
            fieldRegex: '',
            fieldDatabase: ''
        }
    }
    addTemplateHelper = (e) =>{
        var template= {
            name:this.state.name,
            creator: 'Pritish',
            description:this.state.description,
            params: this.state.params
        }
        this.props.addTemplates(template);
        this.props.history.push("/view_templates");
    }
    addField = (e) => {
        e.preventDefault();
        var new_field = {
            fieldName: this.state.field.fieldName,
            fieldRegex: this.state.field.fieldRegex,
            fieldDatabase: this.state.field.fieldDatabase
        };
        var new_params = [...this.state.params, new_field];
        console.log("Added new params")
        console.log(new_field);
        this.setState({
            params: new_params
        });
    }
    addFieldName = (e) => {
        var tempField = this.state.field;
        tempField['fieldName'] = e.target.value;
        console.log(tempField);
        this.setState({
            field: tempField
        });
    }
    addFieldRegex = (e) => {
        var tempField = this.state.field;
        tempField['fieldRegex'] = e.target.value;
        this.setState({
            field: tempField
        });
    }
    addFieldDatabase = (e) => {
        var tempField = this.state.field;
        tempField['fieldDatabase'] = e.target.value;
        this.setState({
            field: tempField
        });
    }
    addName = (e) => {
        this.setState({
            name: e.target.value
        });
    }
    addDescription = (e) => {
        this.setState({
            description: e.target.value
        });
    }
    render() {
        const allfields = this.state.params.map((param) => {
            console.log(param);
            return (
                <tr>
                    <th>{param.fieldName}</th>
                    <th>{param.fieldRegex}</th>
                    <th>{param.fieldDatabase}</th>
                </tr>
            );
        })
        return (
            <div className="container">
                <div class="input-field col s5">
                    <input type="text" class="validate" onChange={this.addName} />
                    <label >Template Name</label>
                </div>
                <div class="input-field col s5">
                    <input type="text" class="validate" onChange={this.addDescription} />
                    <label >Template Description</label>
                </div>
                <form class="col s12" onSubmit={this.addField}>
                    <div class="row">
                        <div class="input-field col s3.5">
                            <input type="tel" class="validate" onChange={this.addFieldName} />
                            <label >fieldName</label>
                        </div>
                        <div class="input-field col s3.5">
                            <input type="tel" class="validate" onChange={this.addFieldRegex} />
                            <label >fieldRegex</label>
                        </div>
                        <div class="input-field col s3.5">
                            <input type="tel" class="validate" onChange={this.addFieldDatabase} />
                            <label >fieldDatabase</label>
                        </div>
                        <button className="btn" type="submit">Add Field</button>
                    </div>
                </form>
                <div>
                    <table>
                        <thead>
                            <tr>
                                <th>fielName</th>
                                <th>fieldRegex</th>
                                <th>fieldDatabase</th>
                            </tr>
                        </thead>
                        <tbody>
                            {allfields}
                        </tbody>
                    </table>
                </div>

                <div className="btn" onClick={this.addTemplateHelper}> Save Template</div>
            </div>
        )
    }
}

export default MakeNewTemplates;