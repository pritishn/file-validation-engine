import React, { Component } from 'react';
import { BrowserRouter, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';

class ShowAllTemplates extends Component {
    render() {
        const {templates} = this.props;

        const temps = templates.map(temp =>{
            return (
            <span class="row">
                <span class="center  col s11 m4">
                <div class="card darken-1">
                    <div class="card-content">
                    <span class="card-title">{temp.name}</span>
                        <p>{temp.description}</p>
                    </div>
                    <div class="card-action">
                        <Link to={'/templates/'+temp.templateID} ></Link>
                    <a href="">View This Template</a>
                    </div>
                </div>
                </span>
          </span>

        ) 
        })
        return (
            <div className="container">
                {temps}
            </div>
            )
    }
}

export default ShowAllTemplates;