import React, { Component } from 'react';
import { BrowserRouter, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';

class Navbar extends Component {
    render() {
        //make navbar here
        return (
            <div className="Navbar">
                <nav>
                    <div className="nav-wrapper black">
                        <a href="#" className="brand-logo">File Validation Engine</a>
                        <ul id="nav-mobile" className="right hide-on-med-and-down">
                            <li><Link to="/">Home </Link></li>
                            {/* <li><Link to="/login">Login </Link></li> */}
                            <li><Link to="/make_template">Make New Template</Link></li>
                            <li><Link to="/view_templates">View Templates</Link></li>
                            <li><Link to="/upload">Upload Page </Link></li>
                        </ul>
                    </div>
                </nav>
            </div>)
    }
}

export default Navbar;