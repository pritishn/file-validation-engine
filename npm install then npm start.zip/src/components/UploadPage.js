import React, { Component } from 'react';
import M from '../materialize';
import ReactDOM from 'react-dom';

class UploadPage extends Component {
    componentDidMount() {
        M.AutoInit(); // initializes the select temlpate button!
    }
    render() {
        return (
            <div className="container">
                <form>
                    <div className="input-field col s12">
                        Select Template To Use:
                    <select>
                            <option value="" disabled selected>Choose your Template:</option>
                            <option value="1">Template 1</option>
                            <option value="2">Template 2</option>
                            <option value="3">Template 3</option>
                        </select>

                    </div>

                    <div className="file-field">
                        <div className="btn">
                            <span>Select CSV File</span>
                            <input type="file" />
                        </div>
                    </div>
                </form>
            </div>)
    }
}

export default UploadPage;