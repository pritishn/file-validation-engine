import Navbar from './components/Navbar';
import UploadPage from './components/UploadPage';
import LoginPage from './components/LoginPage';
import ShowAllTemplates from './components/ShowAllTemplates';
import firebase from './firebase-functions/firebase-init';
import './firebase-functions/firebase-intercations'
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import { render } from '@testing-library/react';
import { Component } from 'react';
import { getAllTemplates, loginWithGooglePopup, saveTemplateToDB } from './firebase-functions/firebase-intercations';
import MakeNewTemplates from './components/MakeNewTemplate';


class App extends Component {

  state = {
    username:'',
    loggedIn:false,
    templates:[]
  }

  getTemplates = async () =>{
      let ret = await getAllTemplates();
      this.setState({
         templates:ret
      });
  }
  addTemplates = (template) =>{
    let new_templates = [...this.state.templates ];
    new_templates.push(template);
    saveTemplateToDB(template);
    this.setState({
      templates:new_templates
    });
  }
  loginUser = () => {
    loginWithGooglePopup().then((res)=>{
      this.setState({
        username : firebase.auth().currentUser.displayName,
        loggedIn : true
      });
      this.getTemplates();
    });
  };
  componentDidMount(){
    this.getTemplates();
  }

  // (firebase.auth().currentUser == null) ? (
  //   <div className="btn" onClick={this.loginUser}>Login!</div>
  // ) : 
  

  render() {

    return (
        <BrowserRouter>
          <div className="App">
            <Navbar />
            <Switch>
              <Route exact path='/' component={LoginPage} />
              <Route exact path='/login' component={LoginPage} />
              <Route exact path='/view_templates'  render={(props)=> <ShowAllTemplates {...props} templates={this.state.templates}/>}/>
              <Route path='/make_template' render={(props)=><MakeNewTemplates {...props} templates={this.state} addTemplates={this.addTemplates}/>} />
              <Route path='/upload' component={UploadPage} />
            </Switch>
          </div>
        </BrowserRouter>
      );
  }
}

export default App;
